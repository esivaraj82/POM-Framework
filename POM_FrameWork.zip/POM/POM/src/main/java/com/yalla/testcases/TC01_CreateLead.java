package com.yalla.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.yalla.pages.LoginPage;
import com.yalla.testng.api.base.Annotations;

public class TC01_CreateLead extends Annotations{
	
	@BeforeTest
	public void setData() {
		testcaseName = "TC01_CreateLead";
		testcaseDec = "Create Lead";
		author = "Sivaraj";
		category = "smoke";
		excelFileName = "CreateLead";
				
	} 

	@Test(dataProvider="fetchData") 
	public void loginAndLogout(String uName, String pwd, String cName, String fName, String lName) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassWord(pwd) 
		.clickLogin()
		.clickCRMSFA()
		.clickLeads()
		.clickCreateLead()
		.companyName(cName)
		.firstName(fName)
		.lastName(lName)
		.clickCreateLead()
		.viewLeadPageTitle();
		
		
		
		
	}
	
}






