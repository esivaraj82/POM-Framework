package com.yalla.pages;

import org.openqa.selenium.support.PageFactory;

import com.yalla.testng.api.base.Annotations;

public class ViewLeadPage extends Annotations{ 
	
	public ViewLeadPage() {
		PageFactory.initElements(driver, this); 
	}
	
		
	public ViewLeadPage viewLeadPageTitle() {
		String title = "View Lead | opentaps CRM";
		verifyTitle(title);
		System.out.println(title);
		takeSnap();
		return this;
	}
	
		
}







