package com.yalla.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.yalla.testng.api.base.Annotations;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateLeadPage extends Annotations{ 
	
	public CreateLeadPage() {
		PageFactory.initElements(driver, this); 
	}
	
	@FindBy(how=How.ID, using="createLeadForm_companyName")  WebElement companyName;
	@FindBy(how=How.ID, using ="createLeadForm_firstName") WebElement firstName;
	@FindBy(how=How.ID, using="createLeadForm_lastName") WebElement lastName;
	@FindBy(how=How.CLASS_NAME, using="smallSubmit") WebElement clickCreateLead;
	
	
	@When("Enter the CompanyNames as (.*)")
	public CreateLeadPage companyName(String data) {
		clearAndType(companyName, data);
		takeSnap();
		return this;
		
	}
	
	@And ("Enter the FirstNames as (.*)")
	public CreateLeadPage firstName(String data) {
		clearAndType(firstName, data);
		takeSnap();
		return this;
		
	}
	
	@And ("Enter the LastNames as (.*)")
	public CreateLeadPage lastName(String data) {
		clearAndType(lastName, data);
		takeSnap();
		return this;
	}
	
	@Then("Click submitButtons")
	public ViewLeadPage clickCreateLead() {
		click(clickCreateLead);
		takeSnap();
		return new ViewLeadPage();
	}
	
}







